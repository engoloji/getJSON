index.html açıldığında sadece 
kategori başlıklarını verip içerikleri döndürmüyorsa
xampp indirip bilgisayarınıza kurun
daha sonra xampp in yüklü olduğu alanda htdocs klasörünün içine
projeyi rardan çıkarıp atın.
daha sonra xampp acıp apache ye start verelim